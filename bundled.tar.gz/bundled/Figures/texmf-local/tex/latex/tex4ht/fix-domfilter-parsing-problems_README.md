https://tex.stackexchange.com/questions/615656/float-placement-for-listings-causes-warnings-in-make4ht

Although things compiled, there were worrisome domfilter errors. This code is a patch which seems to fix them.

