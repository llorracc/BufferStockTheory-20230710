Calibration of the model is found in the context of the code: Code/Python/BufferStockTheory.py
